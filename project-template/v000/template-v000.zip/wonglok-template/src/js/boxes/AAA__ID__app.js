/*
BoxScripts[box.moduleName].box({
  context,
  domElement: mounter,
  pulse,
  inputAt,
  log: (v) => {
    console.log(JSON.stringify(v, null, 4));
  },
  graph: lowdb,
});
*/

import ReactDOM from "react-dom";
import React, { useState, useEffect } from "react";
import { Canvas } from "react-three-fiber";

function EffectNode({ context }) {
  let [element, setReactThreeFiberElement] = useState(null);

  useEffect(() => {
    context.set("mount", (v) => {
      setReactThreeFiberElement(v);
    });
  });

  return <group>{element}</group>;
}

module.exports.box = ({ context, domElement, pulse }) => {
  ReactDOM.render(
    <Canvas>
      <EffectNode context={context}></EffectNode>
      <ambientLight />
      <pointLight position={[10, 10, 10]} />
    </Canvas>,
    domElement
  );
};
