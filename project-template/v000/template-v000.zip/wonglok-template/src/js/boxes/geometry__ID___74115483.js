module.exports.box = () => {
  return {
    name: "geometry",
  };
};
