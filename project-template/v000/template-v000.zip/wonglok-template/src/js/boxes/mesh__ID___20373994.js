/*
BoxScripts[box.moduleName].box({
  context,
  domElement: mounter,
  pulse,
  inputAt,
  log: (v) => {
    console.log(JSON.stringify(v, null, 4));
  },
  graph: lowdb,
});
*/

import React, { useRef, useState, useEffect } from "react";
import { useFrame } from "react-three-fiber";
import { Color } from "three";

function GLBox(props) {
  let { tools } = props;
  const mesh = useRef();
  const mat = useRef();

  const [hovered, setHover] = useState(false);
  const [active, setActive] = useState(false);

  useFrame(() => {
    mesh.current.rotation.x = mesh.current.rotation.y += 0.01;
    if (mesh.current.rotation.rx) {
      mesh.current.rotation.y += mesh.current.rotation.rx;
    }
  });

  useEffect(() => {
    return tools.onBoxChange(({ userData }) => {
      let color = userData.find((e) => e.name === "color").color;
      let speed =
        (userData.find((e) => e.name === "speed").number / 100.0) * 0.1;

      mesh.current.rotation.rx = Number(speed);
      mat.current.color = new Color(color);
    });
  });

  return (
    <mesh
      {...props}
      ref={mesh}
      scale={hovered ? [1.5, active ? 1.5 : 3, 1.5] : [1, 1, 1]}
      onClick={() => setActive(!active)}
      onPointerOver={() => setHover(true)}
      onPointerOut={() => setHover(false)}
    >
      <boxBufferGeometry args={[1, 1, 1]} />
      <meshStandardMaterial ref={mat} />
    </mesh>
  );
}

module.exports.box = async (tools) => {
  let { box, context, inputAt, pulse, log, onBoxChange } = tools;
  let mountFnc = await context.get("mount");
  let newBox = <GLBox tools={tools}></GLBox>;

  mountFnc(newBox);

  let input0 = inputAt(0);
  input0.stream((data) => {
    log(data);
  });
};
