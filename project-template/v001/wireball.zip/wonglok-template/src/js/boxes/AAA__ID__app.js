/*
BoxScripts[box.moduleName].box({
  resources,
  domElement: mounter,
  pulse,
  inputAt,
  log: (v) => {
    console.log(JSON.stringify(v, null, 4));
  },
  graph: lowdb,
});
*/

import ReactDOM from "react-dom";
import React, { useState, useEffect } from "react";
import { Canvas, useThree } from "react-three-fiber";
import { Color } from "three";

function Background() {
  let { scene } = useThree();

  useEffect(() => {
    scene.background = new Color("#000000");
  }, []);

  return <group></group>;
}

function WireBall({ tools, ...props }) {
  let [element, mountElement] = useState(null);

  useEffect(() => {
    tools.pulse({ type: "mount", done: mountElement });
  }, []);

  return <group {...props}>{element}</group>;
}

module.exports.box = ({ resources, domElement, pulse }) => {
  ReactDOM.render(
    <Canvas>
      <Background></Background>

      <WireBall
        scale={[0.75, 0.75, 0.75]}
        position={[-2, 0, 0]}
        tools={{ pulse }}
      ></WireBall>
      <WireBall
        scale={[0.75, 0.75, 0.75]}
        position={[0, 0, 0]}
        tools={{ pulse }}
      ></WireBall>
      <WireBall
        scale={[0.75, 0.75, 0.75]}
        position={[2, 0, 0]}
        tools={{ pulse }}
      ></WireBall>

      <ambientLight />
      <pointLight position={[10, 10, 10]} />
    </Canvas>,
    domElement
  );
};
