var fs = require("fs");
var certOptions = {
  ca: fs.readFileSync(
    `/Volumes/Data/DataCore/WONGLOK/CodeClients/NewLokLok/proxy/_cert/chain1.pem`,
    "utf8"
  ),
  key: fs.readFileSync(
    `/Volumes/Data/DataCore/WONGLOK/CodeClients/NewLokLok/proxy/_cert/privkey1.pem`,
    "utf8"
  ),
  cert: fs.readFileSync(
    `/Volumes/Data/DataCore/WONGLOK/CodeClients/NewLokLok/proxy/_cert/cert1.pem`,
    "utf8"
  ),
};

var https = require("https");
var express = require("express");
var app = express();

// your express configuration here

var httpsServer = https.createServer(certOptions, app);
app.use("/", express.static("./prod"));
httpsServer.listen(8443);
console.log("server https 8443");
