import React, { useRef, useState, useEffect, useMemo } from "react";
// import { useFrame } from "react-three-fiber";
import { Noodles } from "../lib/Noodle";

function FuncNode({ tools, position = [0, 0, 0] }) {
  let noodle = useMemo(() => {
    return new Noodles();
  }, []);
  return <primitive object={noodle.object3d}></primitive>;
}

module.exports.box = async ({ ...tools }) => {
  tools.stream(0, ({ type, done }) => {
    if (type === "mount") {
      done(<FuncNode key={"noodles"} tools={tools}></FuncNode>);
    }
  });
};
